import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public colorFondo = "grey";
  public cambiarColor = false;
  // colorFondo1='grey';
  // colorFondo2='red';
  constructor(public navCtrl: NavController) {

  }

  CambiarColor() {
    if(this.cambiarColor) {
      this.colorFondo = 'grey';
    }
    else {
      this.colorFondo = 'red';
    }
  }

}
